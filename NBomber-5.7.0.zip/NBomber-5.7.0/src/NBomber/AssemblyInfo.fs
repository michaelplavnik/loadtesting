﻿namespace NBomber.AssemblyInfo

open System.Runtime.CompilerServices

[<assembly: InternalsVisibleTo("NBomber.IntegrationTests")>]
[<assembly: InternalsVisibleTo("NBomber.Cluster")>]
[<assembly: InternalsVisibleTo("NBomber.Cluster.IntegrationTests")>]
do()

namespace Demo.HTTP.SimpleBookstore.Contracts
{
    public class Order
    {
        public Guid BookId { get; set; }
        public int Quantaty { get; set; }
    }
}

namespace NBomber.IntegrationTests

open Xunit

[<assembly: CollectionBehavior(CollectionBehavior.CollectionPerAssembly, DisableTestParallelization = true)>]

do()

